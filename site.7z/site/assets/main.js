const langSwitcher = document.getElementById('langSwitcher');
const themeToggle = document.getElementById('themeToggle');
const body = document.body;

// Language Logic
function setLanguage(lang) {
    const enUpdates = document.querySelectorAll('[data-lang="en"]');
    const jaUpdates = document.querySelectorAll('[data-lang="ja"]');

    if (lang === 'ja') {
        enUpdates.forEach(el => el.style.display = 'none');
        jaUpdates.forEach(el => el.style.display = 'inline');
        document.querySelectorAll('h1[data-lang="ja"], h2[data-lang="ja"], h3[data-lang="ja"], p[data-lang="ja"], div[data-lang="ja"]').forEach(el => el.style.display = 'block');
    } else {
        jaUpdates.forEach(el => el.style.display = 'none');
        enUpdates.forEach(el => el.style.display = 'inline');
        document.querySelectorAll('h1[data-lang="en"], h2[data-lang="en"], h3[data-lang="en"], p[data-lang="en"], div[data-lang="en"]').forEach(el => el.style.display = 'block');
    }
}
langSwitcher.addEventListener('change', (e) => setLanguage(e.target.value));

// Theme Logic
function toggleTheme() {
    body.classList.toggle('light-mode');
    const isLight = body.classList.contains('light-mode');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}
themeToggle.addEventListener('click', toggleTheme);

// Initialize Language
setLanguage('en');

// Initialize Theme (Default Dark)
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'light') {
    body.classList.add('light-mode');
}

// 3D Tilt Effect
const heroImageContainer = document.querySelector('.hero-image');
const heroImage = document.querySelector('.hero-image img');

if (heroImageContainer && heroImage) {
    heroImageContainer.addEventListener('mousemove', (e) => {
        const rect = heroImageContainer.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        // Calculate center
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        // Calculate tilt (limit to small amount like +/- 10deg)
        const rotateX = ((y - centerY) / centerY) * -5; // Invert Y for natural feel
        const rotateY = ((x - centerX) / centerX) * 5;

        heroImage.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
    });

    // Reset on mouse leave
    heroImageContainer.addEventListener('mouseleave', () => {
        heroImage.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg)';
        heroImage.style.transition = 'transform 0.5s ease-out'; // Smooth reset
    });

    // Remove transition during movement to prevent lag, add back on leave
    heroImageContainer.addEventListener('mouseenter', () => {
        heroImage.style.transition = 'transform 0.1s ease-out';
    });
}
